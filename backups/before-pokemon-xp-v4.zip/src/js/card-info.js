import { getCharacter } from "./characters.js";
import { createCard, movesFor, defensiveMatchups, damageFor, TYPE_LABELS } from "./battle-model.js";
import { MAX_LEVEL, upgradeCost } from "./progression-model.js";
const escape = (value) => String(value).replace(/[&<>"']/g,(character) => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" })[character]);
const labels = { hp:"PV",attack:"Attaque",defense:"Défense","special-attack":"Attaque spéciale","special-defense":"Défense spéciale",speed:"Vitesse" };
export function cardInfoMarkup(pokemon,owned,coins,characterId=null) {
  const current = createCard(pokemon,owned.level,characterId), maxed = owned.level >= MAX_LEVEL;
  const next = maxed ? current : createCard(pokemon,owned.level+1,characterId);
  const dummy = { types:[],stats:{ defense:60,"special-defense":60 } };
  const cost = upgradeCost(owned), affordable = coins >= cost.coins && owned.copies-1 >= cost.duplicates && !maxed;
  const rows = Object.entries(labels).map(([key,label]) => {
    const before = key === "hp" ? current.maxHp : current.stats[key], after = key === "hp" ? next.maxHp : next.stats[key];
    return `<tr><th scope="row">${label}</th><td>${before}</td><td>${maxed ? "—" : `${after} <strong>+${after-before}</strong>`}</td></tr>`;
  }).join("");
  const matchups = defensiveMatchups(current);
  const chips = (entries) => entries.map(({ type,multiplier }) => `<span>${escape(TYPE_LABELS[type] ?? type)} ×${multiplier}</span>`).join("") || '<span>Aucune</span>';
  return `<div class="card-info-heading">${current.image ? `<img src="${escape(current.image)}" alt="" width="120" height="120">` : ""}<div><p class="eyebrow">CAPACITÉS & AMÉLIORATION</p><h2 id="card-info-title">${escape(pokemon.name.replaceAll("-"," "))}</h2><p>Niveau ${owned.level} · ${owned.copies-1} double(s) · ${coins} or</p></div></div>
    ${getCharacter(characterId) ? `<p class="card-character-note">Bonus de ${getCharacter(characterId).name} inclus dans les PV et les dégâts affichés : ${getCharacter(characterId).bonus}.</p>` : ""}
    <section class="card-capabilities"><h3>Ses 4 attaques</h3>${movesFor(current).map((move,index) => `<p><strong>${index+1}. ${escape(move.name)} :</strong> ${move.category === "special" ? "spéciale" : "physique"} · ${move.types.map(type => TYPE_LABELS[type]).join(" / ")} · puissance ×${move.power} · ${move.cost ? `${move.cost} charges consommées` : "libre, +1 charge"}.</p>`).join("")}<p><strong>Protection :</strong> réduit de moitié la prochaine attaque reçue et ajoute 1 charge. Chaque attaque ou protection consomme le tour. Changer de Pokémon conserve sa charge.</p></section>
    <div class="matchups"><section><h3>Faiblesses</h3><div class="weaknesses">${chips(matchups.filter((item) => item.multiplier > 1))}</div></section><section><h3>Résistances & immunités</h3><div class="resistances">${chips(matchups.filter((item) => item.multiplier < 1))}</div></section></div>
    <h3>${maxed ? "Statistiques au niveau maximum" : `Gains au niveau ${owned.level+1}`}</h3><table class="upgrade-preview"><thead><tr><th>Statistique</th><th>Actuel</th><th>Après amélioration</th></tr></thead><tbody>${rows}</tbody></table>
    <div class="damage-preview"><h3>Gain de dégâts estimé</h3><p>Comparaison contre une cible neutre avec 60 de défense et de défense spéciale, sans protection.</p>${movesFor(current).map((move) => `<div><span>${escape(move.name)}</span><strong>${damageFor(current,dummy,move.id)} → ${damageFor(next,dummy,move.id)} <small>(+${damageFor(next,dummy,move.id)-damageFor(current,dummy,move.id)})</small></strong></div>`).join("")}</div>
    <div class="card-info-upgrade"><p>${maxed ? "Niveau maximum atteint." : `Coût : 100 or + ${cost.duplicates} double(s). Un exemplaire jouable est conservé.`}</p><button type="button" class="battle-start" data-campaign-action="upgrade" data-id="${pokemon.id}" data-campaign-focus="modal-upgrade" ${!affordable ? "disabled" : ""}>${maxed ? "Niveau maximum" : "Améliorer pour 100 or"}</button></div>`;
}
