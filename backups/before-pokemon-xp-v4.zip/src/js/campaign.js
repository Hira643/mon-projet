import { EMPTY, Subject, Subscription, catchError, filter, forkJoin, fromEvent, map, mergeMap, of, switchMap, timer } from "rxjs";
import { getPokemon$ } from "./pokemon.js";
import { attack, beginTurn, createBattle, createCard, defend, selectPokemon } from "./battle-model.js";
import { playerMarkup } from "./battle.js";
import { chooseBotAction } from "./bot.js";
import { BOOSTER_TYPES, DIFFICULTIES, MAX_LEVEL, SAVE_KEY, claimMewGift, TRAINERS, FREE_TRAINERS, canChallengeTrainer, buyBooster, createProfile, loadProfile, openBooster, recordVictory, recordFreeVictory, selectCharacter, replaceDeckCard, saveProfile, totalBoosters, upgradeCard, upgradeCost, xpProgress } from "./progression-model.js";
import { freeTrainersMarkup } from "./free-trainers.js";
import { adventureMarkup } from "./adventure-map.js";
import { getCharacter } from "./characters.js";
import { characterCardsMarkup, characterSummaryMarkup, characterPortraitStyle } from "./character-ui.js";
import { cardInfoMarkup } from "./card-info.js";
import "../css/campaign.css";
import "../css/refinement.css";
import "../css/adventure.css";
import "../css/prestige.css";
import "../css/navigation.css";
import "../css/characters.css";

const escape = (value) => String(value).replace(/[&<>"']/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[character]);
const nameOf = (pokemon, id) => pokemon?.name.replaceAll("-", " ") ?? `Pokémon n° ${id}`;
const imageOf = (pokemon) => pokemon?.sprites?.other?.["official-artwork"]?.front_default ?? pokemon?.sprites?.front_default ?? "";

export function initCampaign() {
  const root = document.querySelector("#campaign-view");
  const subscriptions = new Subscription();
  const pokemon = new Map();
  const requested = new Set();
  const metadata$ = new Subject();
  const fights$ = new Subject();
  const bot$ = new Subject();
  let storage, profile, saveProblem = "", notice = "", panel = "trainers", replacement = null, lastPack = [], inspectedId = null;
  let battle = null, trainer = null, battleId = "", battleCharacterId = null, loading = false, rewardPending = false, rewarded = false;
  try {
    storage = window.localStorage;
    const saved = loadProfile(storage);
    const gifted = claimMewGift(saved);
    saveProfile(storage, gifted);
    profile = gifted;
    if (gifted !== saved) notice = "Cadeau reçu : 10 cartes de Mew ont été ajoutées à ta collection !";
  } catch {
    profile = createProfile();
    storage = null;
    saveProblem = "La sauvegarde locale est indisponible ou illisible. La progression ne sera pas modifiée. Autorise le stockage de ce site pour jouer avec une sauvegarde.";
  }

  let routeRegion = Math.min(9,Math.floor(profile.adventureWins/10)), rewardRolls = [];

  const arena = root.querySelector("#campaign-arena");
  const fightBox = root.querySelector("#campaign-fight");
  const fightStatus = root.querySelector("#campaign-battle-status");

  const renderedMarkup = new Map();
  function writeMarkup(selector, markup) {
    if (renderedMarkup.get(selector) === markup) return;
    root.querySelector(selector).innerHTML = markup;
    renderedMarkup.set(selector, markup);
  }

  function queuePokemon(ids) {
    for (const id of ids) if (!pokemon.has(Number(id)) && !requested.has(Number(id))) {
      requested.add(Number(id));
      metadata$.next(Number(id));
    }
  }

  function commit(change, message = "") {
    try {
      if (!storage) throw new Error(saveProblem);
      const latest = loadProfile(storage);
      const next = change(latest);
      saveProfile(storage, next);
      profile = next;
      notice = message;
      renderHub();
      queuePokemon(Object.keys(profile.collection));
      return true;
    } catch (error) {
      notice = error.message || "Impossible de sauvegarder. L’opération a été annulée.";
      renderHub();
      return false;
    }
  }

  function cardPicture(id, cssClass = "") {
    const data = pokemon.get(Number(id));
    const image = imageOf(data);
    return image ? `<img class="${cssClass}" src="${escape(image)}" alt="" width="100" height="100" loading="lazy">` : '<span class="collection-placeholder" aria-hidden="true">?</span>';
  }

  function renderHub() {
    document.querySelector("#header-gold").textContent = String(profile.coins);
    root.querySelector("#profile-coins").textContent = String(profile.coins);
    root.querySelector("#profile-boosters").textContent = String(totalBoosters(profile));
    root.querySelector("#profile-owned").textContent = `${Object.keys(profile.collection).length}/151`;
    root.querySelector("#profile-defeated").textContent = `${profile.adventureWins}/100`;
    const character=getCharacter(profile.characterId), characterLocked=loading || Boolean(battle && battle.phase!=="over");
    const avatar=root.querySelector("#profile-character-avatar");
    avatar.classList.toggle("character-portrait",Boolean(character));
    avatar.textContent=character ? "" : "TOI";
    avatar.style.cssText=character ? characterPortraitStyle(character) : "";
    root.querySelector("#profile-character-name").textContent=character ? `${character.name} · ${character.role}` : "Aucun personnage sélectionné";
    writeMarkup("#character-summary",characterSummaryMarkup(profile,characterLocked));
    writeMarkup("#character-cards",characterCardsMarkup(profile,Boolean(storage) && !characterLocked));
    root.querySelector("#clear-character").disabled=!profile.characterId || !storage || characterLocked;
    const xp = xpProgress(profile.xp);
    root.querySelector("#profile-level").textContent = `Dresseur niveau ${xp.level}`;
    root.querySelector("#profile-xp-label").textContent = `${xp.current} / ${xp.required} XP`;
    root.querySelector("#profile-xp").max = xp.required;
    root.querySelector("#profile-xp").value = xp.current;
    root.querySelector("#profile-total-xp").textContent = `${profile.xp} XP au total`;

    root.querySelector("#campaign-notice").textContent = saveProblem || notice;
    root.querySelector("#campaign-save-state").textContent = storage ? "Progression sauvegardée dans ce navigateur" : "Sauvegarde indisponible";
    root.querySelector("#campaign-panels").hidden = loading || Boolean(battle);
    const focusKey = document.activeElement?.dataset.campaignFocus;

    writeMarkup("#campaign-deck", profile.deck.map((id) => {
      const card = profile.collection[id];
      return `<li>${cardPicture(id)}<span>${escape(nameOf(pokemon.get(id), id))}</span><small>Niv. ${card.level}</small></li>`;
    }).join(""));

    writeMarkup("#trainer-list",adventureMarkup(profile,routeRegion,Boolean(storage) && !loading));
    writeMarkup("#free-trainer-list",freeTrainersMarkup(profile,Boolean(storage) && !loading));
    root.querySelector("#free-trainer-count").textContent = `${profile.freeDefeatedTrainers.length}/${FREE_TRAINERS.length} vaincus`;

    root.querySelector("#replacement-picker").hidden = replacement === null;
    if (replacement !== null) {
      root.querySelector("#replacement-title").textContent = `Ajouter ${nameOf(pokemon.get(replacement), replacement)} : quelle carte veux-tu remplacer ?`;
      writeMarkup("#replacement-options", profile.deck.map((id) => `<button type="button" data-campaign-action="replace" data-old-id="${id}">${escape(nameOf(pokemon.get(id), id))}</button>`).join(""));
    }

    writeMarkup("#owned-cards", Object.entries(profile.collection).sort(([a], [b]) => Number(a) - Number(b)).map(([key, card]) => {
      const id = Number(key), data = pokemon.get(id), cost = upgradeCost(card), inDeck = profile.deck.includes(id), maxed = card.level >= MAX_LEVEL;
      const canUpgrade = !maxed && card.copies - 1 >= cost.duplicates && profile.coins >= cost.coins && Boolean(storage);
      const maxHp=data ? createCard(data,card.level,profile.characterId).maxHp : null;
      return `<article class="owned-card"><div class="owned-top"><span>#${String(id).padStart(3, "0")}</span><strong>Niv. ${card.level}</strong></div>${cardPicture(id)}<h3>${escape(nameOf(data, id))}</h3><p class="owned-copies">${card.copies - 1} double(s) disponible(s)</p><p class="owned-bonus">${maxHp ? `${maxHp} PV · ` : ""}+${(card.level - 1) * 10} % de statistiques</p><button type="button" class="inspect-button" data-campaign-action="inspect" data-id="${id}" ${!data ? "disabled" : ""}>Capacités & gains ↗</button><button type="button" class="deck-choice" data-campaign-action="deck" data-id="${id}" data-campaign-focus="deck-${id}" ${inDeck ? "disabled" : ""}>${inDeck ? "✓ Dans le deck" : "Mettre dans le deck"}</button><button type="button" class="upgrade-button" data-campaign-action="upgrade" data-id="${id}" data-campaign-focus="upgrade-${id}" ${!canUpgrade ? "disabled" : ""}>${maxed ? "Niveau maximum" : `Améliorer → Niv. ${card.level + 1}`}</button><p class="upgrade-cost">${maxed ? "Carte améliorée au maximum" : `${cost.duplicates} double(s) + 100 or`}</p></article>`;
    }).join(""));

    writeMarkup("#booster-shop", Object.values(BOOSTER_TYPES).map((pack) => `<article class="shop-pack pack-${pack.id}"><div class="shop-pack-art" aria-hidden="true"><span>KANTO</span><span class="pokeball"></span><strong>${pack.cards}</strong><small>CARTES</small></div><h3>${pack.name}</h3><p>${pack.cards} cartes · ${pack.guaranteed} double(s) garanti(s)</p><button type="button" class="buy-pack-button" data-campaign-action="buy" data-pack="${pack.id}" ${profile.coins < pack.price || !storage ? "disabled" : ""}>Acheter · ${pack.price} or</button><small class="pack-stock">En réserve : ${profile.boosters[pack.id]}</small><button type="button" class="open-pack-button" data-campaign-action="open" data-pack="${pack.id}" ${profile.boosters[pack.id] < 1 || !storage ? "disabled" : ""}>Ouvrir · ${pack.cards} cartes</button></article>`).join(""));
    root.querySelector("#booster-results").hidden = lastPack.length === 0;
    writeMarkup("#booster-cards", lastPack.map(({ id, isNew }) => `<article class="booster-result-card"><span class="reveal-label ${isNew ? "new-card" : "duplicate-card"}">${isNew ? "Nouvelle carte" : "Double obtenu"}</span>${cardPicture(id)}<h3>${escape(nameOf(pokemon.get(id), id))}</h3><p>#${String(id).padStart(3, "0")} · ${profile.collection[id].copies - 1} double(s)</p></article>`).join(""));
    if (inspectedId !== null && pokemon.has(inspectedId)) writeMarkup("#card-info-body", cardInfoMarkup(pokemon.get(inspectedId),profile.collection[inspectedId],profile.coins,profile.characterId));
    for (const button of root.querySelectorAll("[data-campaign-panel]")) {
      button.setAttribute("aria-pressed", String(button.dataset.campaignPanel === panel));
      button.disabled = loading || Boolean(battle && battle.phase !== "over");
    }
    for (const section of root.querySelectorAll("[data-campaign-section]")) section.hidden = section.dataset.campaignSection !== panel;
    if (focusKey) Array.from(root.querySelectorAll("[data-campaign-focus]")).find((element) => element.dataset.campaignFocus === focusKey && !element.disabled)?.focus({ preventScroll: true });
  }

  function showPanel(next) {
    if (battle || loading) {
      if (battle?.phase !== "over" || !closeFight()) return;
    }
    panel = next;
    renderHub();
    root.querySelector(`[data-campaign-section="${next}"]`)?.scrollIntoView({ block: "start", behavior: "smooth" });
  }

  function claimReward() {
    if (!rewardPending || !trainer) return true;
    if (!rewardRolls.length) rewardRolls = Array.from({ length:10 },() => Math.random());
    let rollIndex = 0;
    const free = trainer.mode === "free";
    const saved = commit((current) => free ? recordFreeVictory(current,trainer.id,battleId,{characterId:battleCharacterId}) : recordVictory(current, trainer.id, battleId,() => rewardRolls[rollIndex++],{characterId:battleCharacterId}), free ? "Victoire ! Ton or et ton XP sont sauvegardés. Tu peux réaffronter ce dresseur." : "Victoire ! La prochaine rencontre est débloquée et tes récompenses sont sauvegardées.");
    if (saved) { rewardPending = false; rewarded = true; routeRegion = Math.min(9,Math.floor(profile.adventureWins/10)); renderHub(); }
    return saved;
  }

  function renderFight() {
    fightBox.hidden = !loading && !battle;
    root.querySelector("#campaign-arena").hidden = !battle;
    root.querySelector("#campaign-fight-name").textContent = trainer ? `Toi contre ${trainer.name}` : "Combat";
    root.querySelector("#campaign-fight-round").textContent = battle ? `TOUR ${battle.turnNumber}` : "PRÉPARATION";
    root.querySelector('[data-campaign-action="back"]').textContent = trainer?.mode === "free" ? "Retour aux dresseurs" : "Retour à la route";
    const result = root.querySelector("#campaign-result");
    result.hidden = !battle || battle.phase !== "over";
    if (loading) { fightStatus.textContent = "Chargement de ton deck et de l’équipe adverse…"; return; }
    if (!battle) return;
    arena.innerHTML = playerMarkup(battle, 0, { label: "Ton équipe", idPrefix: "campaign" }) + '<span class="arena-vs" aria-hidden="true">VS</span>' + playerMarkup(battle, 1, { label: trainer.name, controlled: false, idPrefix: "campaign", portraitIndex: trainer.portraitIndex });
    fightStatus.textContent = battle.phase === "over" ? battle.winner === 0 ? `Victoire ! Tu as vaincu ${trainer.name}.` : `Défaite face à ${trainer.name}. Réessaie avec une autre équipe ou améliore tes cartes !` : battle.turn === 0 ? "À toi de jouer : choisis ton Pokémon et attaque !" : `${trainer.name} réfléchit… Le robot joue automatiquement.`;
    root.querySelector("#campaign-fight-log").replaceChildren(...battle.log.slice().reverse().map((line) => {
      const item = document.createElement("li");
      item.textContent = line.replaceAll("Joueur 1", "Toi").replaceAll("Joueur 2", trainer.name);
      return item;
    }));
    if (battle.phase === "over") {
      root.querySelector("#campaign-result-title").textContent = battle.winner === 0 ? "Combat remporté !" : "Ce n’est que partie remise.";
      root.querySelector("#campaign-result-text").textContent = battle.winner === 0 ? rewarded ? trainer.mode === "free" ? `Tu as battu ${trainer.name} ! Tu peux le réaffronter pour gagner à nouveau de l’or.` : `Étape ${trainer.stage} remportée ! ${profile.adventureWins === 100 ? "Les 100 rencontres sont terminées." : `La rencontre ${profile.adventureWins+1} est débloquée.`}` : "Ta récompense attend sa sauvegarde. Réessaie de la récupérer." : "Ton deck et ta collection sont conservés. Aucun frais, aucune carte perdue.";
      const rewardCharacter=getCharacter(battleCharacterId);
      const reward = profile.lastReward?.battleId === battleId ? profile.lastReward : null;
      writeMarkup("#adventure-rewards", reward && rewarded ? `<div class="reward-summary"><span><strong>+${reward.coins}</strong> OR</span><span><strong>+${reward.xp}</strong> XP</span>${reward.cards.length ? `<span><strong>+${reward.cards.length}</strong> CARTE(S)</span>` : ""}</div><div class="reward-cards">${reward.cards.map(id => `<div>${cardPicture(id)}<span>${escape(nameOf(pokemon.get(id),id))}</span><small>${profile.collection[id].copies-1} double(s) disponible(s)</small></div>`).join("")}</div>${rewardCharacter ? `<p class="reward-character-note">Bonus de ${rewardCharacter.name} inclus : ${rewardCharacter.bonus}.</p>` : ""}<p class="reward-saved">✓ Récompenses ajoutées à ta sauvegarde${trainer.stage%10===0 ? " · Bonus de gardien inclus !" : ""}</p>` : "");
      root.querySelector("#continue-adventure").textContent = trainer.mode === "free" ? "Revoir les dresseurs →" : "Continuer l’aventure →";
      root.querySelector("#continue-adventure").hidden = battle.winner !== 0 || !rewarded;
      root.querySelector("#claim-reward").hidden = !rewardPending;
      root.querySelector("#open-reward-boosters").hidden = battle.winner !== 0 || !rewarded;
    }
  }

  function setBattle(next) {
    bot$.next(null);
    battle = next;
    if (battle.phase === "handoff" && battle.turn === 0) battle = beginTurn(battle, 0);
    if (battle.phase === "over" && battle.winner === 0 && !rewarded) { rewardPending = true; claimReward(); }
    renderFight();
    if (battle.phase !== "over" && battle.turn === 1) bot$.next({ state: battle, token: battleId });
  }

  function closeFight() {
    if (rewardPending && !claimReward()) return false;
    bot$.next(null);
    fights$.next(null);
    battle = null;
    loading = false;
    trainer = null;
    battleCharacterId = null;
    rewardPending = false;
    rewarded = false;
    renderFight();
    renderHub();
    return true;
  }

  function startFight(id) {
    const selected = [...TRAINERS,...FREE_TRAINERS].find((item) => item.id === id);
    if (!selected || !storage || loading) return;
    if (rewardPending && !claimReward()) return;
    try { profile = loadProfile(storage); } catch { return; }
    if (selected.mode !== "free" && !canChallengeTrainer(profile,id)) { notice = "Tu dois affronter les dresseurs dans l’ordre : 1, puis 2, puis 3…"; renderHub(); return; }
    if (battle && battle.phase !== "over") return;
    rewardRolls = [];
    battleCharacterId = profile.characterId;
    bot$.next(null);
    trainer = selected;
    battleId = crypto.randomUUID();
    battle = null;
    loading = true;
    rewarded = false;
    rewardPending = false;
    notice = "";
    renderHub();
    renderFight();
    fightBox.scrollIntoView({ block: "start", behavior: "smooth" });
    fights$.next({ trainer: selected, token: battleId, characterId:battleCharacterId, deck: [...profile.deck], levels: profile.deck.map((pokemonId) => profile.collection[pokemonId].level) });
  }

  subscriptions.add(metadata$.pipe(mergeMap((id) => getPokemon$(String(id)).pipe(
    map((data) => ({ id, data })),
    catchError(() => { requested.delete(id); return of(null); })
  ), 4)).subscribe((result) => {
    if (result) pokemon.set(result.id, result.data);
    renderHub();
    if (battle?.phase === "over") renderFight();
  }));

  subscriptions.add(fights$.pipe(switchMap((request) => request ? forkJoin([...request.deck, ...request.trainer.team].map((id) => getPokemon$(String(id)))).pipe(
    map((cards) => ({ request, cards })),
    catchError(() => of({ request, error: true }))
  ) : EMPTY)).subscribe((result) => {
    if (result.request.token !== battleId) return;
    loading = false;
    if (result.error) {
      notice = "Impossible de charger ce combat depuis PokéAPI. Réessaie ; aucune pièce ni carte n’a été dépensée.";
      battle = null;
      renderHub();
      renderFight();
      return;
    }
    for (const card of result.cards) pokemon.set(card.id, card);
    try {
      setBattle(createBattle(result.cards, { allowSharedSpecies: true, playerCharacterId:result.request.characterId, levels: [...result.request.levels, ...Array(5).fill(result.request.trainer.level)] }));
      renderHub();
    } catch (error) {
      battle = null;
      notice = error.message;
      renderHub();
      renderFight();
    }
  }));

  subscriptions.add(bot$.pipe(switchMap((request) => request ? timer(700).pipe(map(() => request)) : EMPTY)).subscribe(({ state, token }) => {
    if (token !== battleId || state !== battle || battle.phase === "over") return;
    let next = state.phase === "handoff" ? beginTurn(state, 1) : state;
    const action = chooseBotAction(next, trainer.difficulty);
    if (!action) return;
    next = selectPokemon(next, 1, action.index);
    next = action.kind === "guard" ? defend(next,1) : attack(next,1,action.kind);
    setBattle(next);
    if (next.phase === "over") renderHub();
  }));

  subscriptions.add(fromEvent(root, "click").subscribe((event) => {
    const panelButton = event.target.closest("[data-campaign-panel]");
    if (panelButton && !panelButton.disabled) { showPanel(panelButton.dataset.campaignPanel); return; }
    const button = event.target.closest("button[data-campaign-action]");
    if (!button || button.disabled || !root.contains(button)) return;
    const action = button.dataset.campaignAction;
    const id = Number(button.dataset.id);
    if (action === "choose-character") {
      if (loading || (battle && battle.phase!=="over")) { notice="Choisis ton personnage entre deux combats."; renderHub(); return; }
      const characterId=button.dataset.character || null, chosen=getCharacter(characterId);
      commit(current=>selectCharacter(current,characterId),chosen ? `${chosen.name} sélectionné${["aurore","lyra","enora","naya","tess"].includes(characterId) ? "e" : ""} ! ${chosen.bonus}.` : "Personnage retiré. Tu joues avec les valeurs de base.");
    }
    if (action === "fight") startFight(button.dataset.trainer);
    if (action === "free-level") { const level = Number(button.dataset.level); root.querySelector(`#free-level-group-${level}`)?.scrollIntoView({block:"start",behavior:"smooth"}); }
    if (action === "region") { routeRegion = Math.max(0,Math.min(9,Number(button.dataset.region))); renderHub(); }
    if (action === "route-current") { routeRegion = Math.min(9,Math.floor(profile.adventureWins/10)); renderHub(); }
    if (action === "continue") { const nextPanel = trainer?.mode === "free" ? "free" : "trainers"; if (closeFight()) { routeRegion = Math.min(9,Math.floor(profile.adventureWins/10)); showPanel(nextPanel); } }
    if (action === "back") closeFight();
    if (action === "upgrade") commit((current) => upgradeCard(current, id), "Carte améliorée ! Ses statistiques augmentent de 10 % de leur valeur de base par niveau.");
    if (action === "deck") { replacement = id; renderHub(); root.querySelector("#replacement-picker").scrollIntoView({ block: "center", behavior: "smooth" }); }
    if (action === "replace") {
      const newId = replacement;
      if (commit((current) => replaceDeckCard(current, Number(button.dataset.oldId), newId), "Ton deck de 5 cartes a été mis à jour.")) replacement = null;
      renderHub();
    }
    if (action === "cancel-replace") { replacement = null; renderHub(); }
    if (action === "buy") commit((current) => buyBooster(current,button.dataset.pack), "Booster acheté ! Tu peux maintenant l’ouvrir dans la boutique.");
    if (action === "open") {
      let opened;
      if (commit((current) => { opened = openBooster(current,button.dataset.pack); return opened.profile; }, `${BOOSTER_TYPES[button.dataset.pack].cards} cartes ajoutées à ta collection.`)) {
        lastPack = opened.cards;
        root.querySelector("#booster-results-title").textContent = `Tes ${lastPack.length} cartes obtenues`;
        renderHub();
        queuePokemon(lastPack.map((card) => card.id));
      }
    }
    if (action === "inspect") {
      inspectedId = id;
      renderHub();
      root.querySelector("#card-info-dialog").showModal();
    }
    if (action === "close-card") root.querySelector("#card-info-dialog").close();
    if (action === "reward") { claimReward(); renderFight(); }
    if (action === "boosters") { if (closeFight()) showPanel("boosters"); }
  }));

  subscriptions.add(fromEvent(arena, "click").subscribe((event) => {
    const button = event.target.closest("button[data-action]");
    if (!button || button.disabled || !battle || battle.phase !== "playing" || battle.turn !== 0 || Number(button.dataset.player) !== 0) return;
    if (button.dataset.action === "select") setBattle(selectPokemon(battle, 0, Number(button.dataset.index)));
    if (button.dataset.action === "guard") setBattle(defend(battle,0));
    if (button.dataset.action === "attack") setBattle(attack(battle, 0, button.dataset.kind));
  }));

  subscriptions.add(fromEvent(window, "storage").pipe(filter((event) => event.key === SAVE_KEY)).subscribe(() => {
    if (!storage) return;
    try { profile = loadProfile(storage); renderHub(); queuePokemon(Object.keys(profile.collection)); } catch { notice = "La sauvegarde a changé et ne peut pas être relue."; renderHub(); }
  }));

  const modes = [
    ["#show-campaign", "#campaign-view"],
    ["#show-battle", "#battle-view"],
    ["#show-pokedex", "#pokedex-view"]
  ];
  for (const [buttonSelector, viewSelector] of modes) subscriptions.add(fromEvent(document.querySelector(buttonSelector), "click").subscribe(() => {
    for (const [otherButton, otherView] of modes) {
      document.querySelector(otherButton).setAttribute("aria-pressed", String(otherView === viewSelector));
      document.querySelector(otherView).hidden = otherView !== viewSelector;
    }
  }));

  subscriptions.add(() => { metadata$.complete(); fights$.complete(); bot$.complete(); });
  renderHub();
  queuePokemon(Object.keys(profile.collection));
  return subscriptions;
}
