// Source : PokeAPI/pokeapi data/v2/csv/type_efficacy.csv (relations modernes).
export const TYPE_CHART = {
  "normal": {
    "rock": 0.5,
    "ghost": 0.0,
    "steel": 0.5
  },
  "fighting": {
    "normal": 2.0,
    "flying": 0.5,
    "poison": 0.5,
    "rock": 2.0,
    "bug": 0.5,
    "ghost": 0.0,
    "steel": 2.0,
    "psychic": 0.5,
    "ice": 2.0,
    "dark": 2.0,
    "fairy": 0.5
  },
  "flying": {
    "fighting": 2.0,
    "rock": 0.5,
    "bug": 2.0,
    "steel": 0.5,
    "grass": 2.0,
    "electric": 0.5
  },
  "poison": {
    "poison": 0.5,
    "ground": 0.5,
    "rock": 0.5,
    "ghost": 0.5,
    "steel": 0.0,
    "grass": 2.0,
    "fairy": 2.0
  },
  "ground": {
    "flying": 0.0,
    "poison": 2.0,
    "rock": 2.0,
    "bug": 0.5,
    "steel": 2.0,
    "fire": 2.0,
    "grass": 0.5,
    "electric": 2.0
  },
  "rock": {
    "fighting": 0.5,
    "flying": 2.0,
    "ground": 0.5,
    "bug": 2.0,
    "steel": 0.5,
    "fire": 2.0,
    "ice": 2.0
  },
  "bug": {
    "fighting": 0.5,
    "flying": 0.5,
    "poison": 0.5,
    "ghost": 0.5,
    "steel": 0.5,
    "fire": 0.5,
    "grass": 2.0,
    "psychic": 2.0,
    "dark": 2.0,
    "fairy": 0.5
  },
  "ghost": {
    "normal": 0.0,
    "ghost": 2.0,
    "psychic": 2.0,
    "dark": 0.5
  },
  "steel": {
    "rock": 2.0,
    "steel": 0.5,
    "fire": 0.5,
    "water": 0.5,
    "electric": 0.5,
    "ice": 2.0,
    "fairy": 2.0
  },
  "fire": {
    "rock": 0.5,
    "bug": 2.0,
    "steel": 2.0,
    "fire": 0.5,
    "water": 0.5,
    "grass": 2.0,
    "ice": 2.0,
    "dragon": 0.5
  },
  "water": {
    "ground": 2.0,
    "rock": 2.0,
    "fire": 2.0,
    "water": 0.5,
    "grass": 0.5,
    "dragon": 0.5
  },
  "grass": {
    "flying": 0.5,
    "poison": 0.5,
    "ground": 2.0,
    "rock": 2.0,
    "bug": 0.5,
    "steel": 0.5,
    "fire": 0.5,
    "water": 2.0,
    "grass": 0.5,
    "dragon": 0.5
  },
  "electric": {
    "flying": 2.0,
    "ground": 0.0,
    "water": 2.0,
    "grass": 0.5,
    "electric": 0.5,
    "dragon": 0.5
  },
  "psychic": {
    "fighting": 2.0,
    "poison": 2.0,
    "steel": 0.5,
    "psychic": 0.5,
    "dark": 0.0
  },
  "ice": {
    "flying": 2.0,
    "ground": 2.0,
    "steel": 0.5,
    "fire": 0.5,
    "water": 0.5,
    "grass": 2.0,
    "ice": 0.5,
    "dragon": 2.0
  },
  "dragon": {
    "steel": 0.5,
    "dragon": 2.0,
    "fairy": 0.0
  },
  "dark": {
    "fighting": 0.5,
    "ghost": 2.0,
    "psychic": 2.0,
    "dark": 0.5,
    "fairy": 0.5
  },
  "fairy": {
    "fighting": 2.0,
    "poison": 0.5,
    "steel": 0.5,
    "fire": 0.5,
    "dragon": 2.0,
    "dark": 2.0
  }
};
